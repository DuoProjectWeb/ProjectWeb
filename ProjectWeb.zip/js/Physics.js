var Physics = function(){
	this.Layer_Default = 0;
	this.Layer_Player = 1;
	this.Layer_Bullet = 2;
	this.Layer_Enemy = 3;
	this.Layer_Bomb = 4;
};
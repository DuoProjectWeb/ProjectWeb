var ParticuleInfluencer = function(){

};

ParticuleInfluencer.prototype.initialize = function(p) {
	
};

ParticuleInfluencer.prototype.influence = function(p, tpf) {
	
};
var Drawable = function(){
	this.name = "Unknown";
	this.renderingLayer = 0;
};

Drawable.prototype.render = function(g){
};